package spring.framework.utils;

public class Messages {
}
