package spring.framework.utils;

public class Constants {

    public static final String UPLOAD_PATH = "D:\\Licenta2018\\Licenta\\DatabaseAPI\\";

}
