package spring.framework.boundry.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ActivityDomainDTO {

    private Long id;
    private String name;

}
