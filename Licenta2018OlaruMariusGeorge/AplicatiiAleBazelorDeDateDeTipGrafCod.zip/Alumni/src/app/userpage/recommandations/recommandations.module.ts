import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RecommandationsRoutingModule } from './recommandations-routing.module';

@NgModule({
  imports: [
    CommonModule,
    RecommandationsRoutingModule
  ],
  declarations: []
})
export class RecommandationsModule { }
