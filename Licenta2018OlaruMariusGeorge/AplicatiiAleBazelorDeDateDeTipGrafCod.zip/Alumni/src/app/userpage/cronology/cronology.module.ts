import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CronologyRoutingModule } from './cronology-routing.module';

@NgModule({
  imports: [
    CommonModule,
    CronologyRoutingModule
  ],
  declarations: []
})
export class CronologyModule { }
