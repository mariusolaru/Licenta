import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FollowspostsRoutingModule } from './followsposts-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FollowspostsRoutingModule
  ],
  declarations: []
})
export class FollowspostsModule { }
