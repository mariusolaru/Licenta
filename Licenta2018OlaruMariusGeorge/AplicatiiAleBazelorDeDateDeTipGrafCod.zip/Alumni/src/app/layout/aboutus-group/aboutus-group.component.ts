import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';

@Component({
  selector: 'app-aboutus-group',
  templateUrl: './aboutus-group.component.html',
  styleUrls: ['./aboutus-group.component.scss'],
  animations: [routerTransition()] 
})
export class AboutusGroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
