export class Article {
    userId: any;
    title: string;
    content: any;
}

export class ReceivedArticle{
    title : string;
    content : any;
    postingDate : any;
}

export class Eventy {
    userId: any;
    title: string;
    content: any;
}