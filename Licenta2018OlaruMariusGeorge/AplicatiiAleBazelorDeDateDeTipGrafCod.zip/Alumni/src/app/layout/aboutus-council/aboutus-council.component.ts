import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';

@Component({
  selector: 'app-aboutus-council',
  templateUrl: './aboutus-council.component.html',
  styleUrls: ['./aboutus-council.component.scss'],
  animations: [routerTransition()] 
})
export class AboutusCouncilComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
