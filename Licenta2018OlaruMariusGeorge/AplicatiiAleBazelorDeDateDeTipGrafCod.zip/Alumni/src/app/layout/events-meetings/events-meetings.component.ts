import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';

@Component({
  selector: 'app-events-meetings',
  templateUrl: './events-meetings.component.html',
  styleUrls: ['./events-meetings.component.scss'],
  animations: [routerTransition()] 
})
export class EventsMeetingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
